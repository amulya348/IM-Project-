import streamlit as st
from model import evaluate_idea

# Page setup
st.set_page_config(page_title="Startup Validator", page_icon="🚀")

# Title
st.title("🚀 Startup Idea Validator")

# Description
st.write("Enter your startup idea and get AI-based feedback")

# Input box
idea = st.text_area("💡 Enter your idea here:")

# Button
if st.button("Validate Idea"):
    if idea.strip() == "":
        st.warning("Please enter an idea")
    else:
        score, verdict = evaluate_idea(idea)

        st.subheader("📊 Results")
        st.write(f"Score: {score}%")
        st.write(f"Verdict: {verdict}")

        # Progress bar
        st.progress(int(score))

        # Suggestions
        if score < 50:
            st.info("Improve uniqueness and solve real problems.")
        elif score < 80:
            st.info("Good idea. Improve execution and scalability.")
        else:
            st.success("Excellent idea! Ready for MVP 🚀")