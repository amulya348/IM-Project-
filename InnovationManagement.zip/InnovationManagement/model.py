from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from utils import clean_text

# Training data (simple demo dataset)
ideas = [
    "AI healthcare prediction system",
    "blockchain voting platform",
    "mental health chatbot",
    "food delivery app",
    "online education platform",
    "copy of facebook",
    "random useless idea",
    "duplicate taxi app"
]

labels = [1, 1, 1, 1, 1, 0, 0, 0]

# Clean data
cleaned_ideas = [clean_text(i) for i in ideas]

# Vectorization
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(cleaned_ideas)

# Train model
model = LogisticRegression()
model.fit(X, labels)

def evaluate_idea(text):
    text = clean_text(text)
    vec = vectorizer.transform([text])
    
    prob = model.predict_proba(vec)[0][1]
    score = round(prob * 100, 2)

    if score > 70:
        verdict = "🔥 High Potential Startup Idea"
    elif score > 40:
        verdict = "⚡ Moderate Potential"
    else:
        verdict = "❌ Low Potential / Needs Improvement"

    return score, verdict